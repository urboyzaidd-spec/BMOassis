# BMO Assistant (Android)

A Kotlin + Jetpack Compose + Material 3 starter project for Android 12+.

## Included
- Compose chat UI, conversation history for the current app session, mute control and settings.
- Animated, custom-drawn 2D BMO-style avatar with idle/listening/thinking/speaking states.
- Push-to-talk using Android `SpeechRecognizer`; configure English or Arabic speech recognition.
- Android Text-to-Speech replies in English by default with adjustable rate.
- Configurable OpenAI-compatible chat-completions endpoint and API key.
- Optional floating avatar overlay using Android's `SYSTEM_ALERT_WINDOW` permission.
- Dark Material 3 styling.

## Build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder (`BMOAssistant`) in Android Studio.
3. Allow Gradle sync to finish.
4. Run on an Android 12+ device or emulator. A physical device is recommended for speech recognition and TTS.
5. Grant microphone permission when prompted.

## Configure AI backend
Open **Settings** in the app:
- **API base URL**: full chat-completions endpoint, e.g. `https://your-server.example/v1/chat/completions`.
- **API key**: bearer token accepted by your server.
- The request body follows the common OpenAI-compatible `{ model, messages, temperature }` convention. The default model string is `gpt-4o-mini`; change it in `AssistantCore.kt` if your backend uses another model.
- For production, avoid embedding a long-lived secret in a client app. Prefer a small authenticated proxy backend, HTTPS, rate limits, and server-side key storage.

## Floating overlay
1. Tap **Float BMO** or **Enable floating BMO overlay**.
2. Android opens the “Display over other apps” settings page.
3. Enable permission for **BMO Assistant**.
4. Return to the app and tap the overlay option again.

The overlay currently renders an animated avatar only. Android may restrict background services; this starter deliberately does not start a microphone service in the background.

## Wake word status and testing
**Important implementation limitation:** continuous on-device “BMO” wake-word detection is not implemented in this starter. The Settings toggle and sensitivity value are saved as preparation for an engine integration, but do not activate listening. No audio is sent to the AI backend until the user taps the microphone or submits text. This avoids misleading users about always-on listening.

To test the working voice path:
1. Set your backend endpoint/key in Settings (or leave the placeholder to test the UI response).
2. Tap the microphone icon and say a short English question.
3. The Android recognizer transcribes it; the app submits the text to the configured backend.
4. BMO reads the response aloud in English unless muted.

## Acceptance test status
- [x] App module, Gradle setup and manifest included.
- [x] Chat/text mode, push-to-talk, TTS, settings, animated avatar and overlay avatar.
- [ ] True always-on wake word.
- [ ] Live synchronization between TTS audio and avatar mouth.
- [ ] Persistent database-backed conversation history.
- [ ] Full 3D model / renderer.

The avatar is an original Canvas-drawn 2D fallback, not a 3D asset. It is animated and never renders as a blank box. The voice speaking animation is state-based rather than phoneme/audio-synchronized.
