package com.example.bmoassistant

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.ui.platform.ComposeView
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class BmoOverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var overlay: ComposeView? = null
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = ComposeView(this).apply {
            setContent {
                MaterialTheme(colorScheme = darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF35DCC3))) {
                    BmoAvatar(BmoState.IDLE, Modifier.width(110.dp).height(145.dp), compact = true)
                }
            }
        }
        val params = WindowManager.LayoutParams(
            150, 180, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL; x = 0; y = 0 }
        try { windowManager?.addView(overlay, params) } catch (_: Exception) { stopSelf() }
    }
    override fun onDestroy() { overlay?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }; overlay = null; super.onDestroy() }
}
