package com.example.bmoassistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import java.util.Locale

private val Teal = Color(0xFF35DCC3)
private val Deep = Color(0xFF082A32)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Teal, secondary = Color(0xFFFFD36E), background = Deep, surface = Color(0xFF103C45))) { BmoApp(::speak, ::startOverlay) } }
    }
    override fun onInit(status: Int) { ttsReady = status == TextToSpeech.SUCCESS; if (ttsReady) { tts?.language = Locale.US; tts?.setSpeechRate(1f) } }
    private fun speak(text: String, speed: Float = 1f) { if (ttsReady) { tts?.setLanguage(Locale.US); tts?.setSpeechRate(speed.coerceIn(0.7f,1.3f)); tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bmo-reply") } }
    private fun startOverlay() { if (Settings.canDrawOverlays(this)) startService(Intent(this, BmoOverlayService::class.java)) else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)) }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BmoApp(speak: (String, Float) -> Unit, startOverlay: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { BmoPrefs(context) }
    val ai = remember { AiClient(prefs) }
    val scope = rememberCoroutineScope()
    var state by remember { mutableStateOf(BmoState.IDLE) }
    var screen by remember { mutableStateOf("Home") }
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf(ChatMessage("Hey BMO!", "Beep boop! Hi! I'm BMO. Ask me anything, or tap the mic to talk."))) }
    var error by remember { mutableStateOf("") }
    var speechRecognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) beginListening(context, prefs) { heard -> input = heard; state = BmoState.THINKING; scope.launch { val answer = ai.reply(heard); messages = messages + ChatMessage(heard, answer); state = BmoState.SPEAKING; if (!prefs.muted) speak(answer, prefs.speed); state = BmoState.IDLE } }
        else error = "Microphone permission is needed only when you choose to talk to BMO."
    }
    Scaffold(
        topBar = { TopAppBar(title = { Text("BMO Assistant", fontWeight = FontWeight.Bold) }, actions = {
            IconButton(onClick = { prefs.muted = !prefs.muted }) { Icon(if (prefs.muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp, "Mute voice") }
            IconButton(onClick = { screen = if (screen == "Settings") "Home" else "Settings" }) { Icon(Icons.Default.Settings, "Settings") }
        }) },
        bottomBar = { NavigationBar { NavigationBarItem(selected = screen == "Home", onClick = { screen = "Home" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Chat") }); NavigationBarItem(selected = screen == "History", onClick = { screen = "History" }, icon = { Icon(Icons.Default.History, null) }, label = { Text("History") }); NavigationBarItem(selected = screen == "Settings", onClick = { screen = "Settings" }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") }) } }
    ) { padding ->
        when (screen) {
            "Settings" -> SettingsScreen(prefs, startOverlay, Modifier.padding(padding))
            "History" -> HistoryScreen(messages, Modifier.padding(padding))
            else -> Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth().height(260.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Hi! I'm BMO.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text(when(state) { BmoState.IDLE -> "Ready for an adventure!"; BmoState.LISTENING -> "I'm listening!"; BmoState.THINKING -> "Hmm... thinking!"; BmoState.SPEAKING -> "Beep boop! Talking!" }, color = Teal)
                        Spacer(Modifier.height(12.dp))
                        AssistChip(onClick = { startOverlay() }, label = { Text("Float BMO") }, leadingIcon = { Icon(Icons.Default.PictureInPictureAlt, null) })
                    }
                    BmoAvatar(state, Modifier.width(170.dp).height(250.dp))
                }
                Text("Conversation", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
                    items(messages) { msg ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF123E47))) {
                            Column(Modifier.padding(12.dp)) {
                                Text("YOU", color = Teal, style = MaterialTheme.typography.labelSmall)
                                Text(msg.user)
                                Spacer(Modifier.height(8.dp))
                                Text("BMO", color = Color(0xFFFFD36E), style = MaterialTheme.typography.labelSmall)
                                Text(msg.assistant)
                            }
                        }
                    }
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 10.dp)) {
                    OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Talk to BMO...") }, maxLines = 3)
                    IconButton(onClick = {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            beginListening(context, prefs) { heard -> input = heard; state = BmoState.THINKING; scope.launch { val answer = ai.reply(heard); messages = messages + ChatMessage(heard, answer); state = BmoState.SPEAKING; if (!prefs.muted) speak(answer, prefs.speed); state = BmoState.IDLE } }
                        } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    }) { Icon(Icons.Default.Mic, "Push to talk", tint = Teal) }
                    IconButton(onClick = {
                        val prompt = input.trim()
                        if (prompt.isNotEmpty()) { input = ""; state = BmoState.THINKING; scope.launch { val answer = ai.reply(prompt); messages = messages + ChatMessage(prompt, answer); state = BmoState.SPEAKING; if (!prefs.muted) speak(answer, prefs.speed); state = BmoState.IDLE } }
                    }) { Icon(Icons.Default.Send, "Send", tint = Teal) }
                }
            }
        }
    }
}

private fun beginListening(context: android.content.Context, prefs: BmoPrefs, onResult: (String) -> Unit) {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) return
    val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (prefs.language == "Iraqi Arabic") "ar-IQ" else "en-US")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
    }
    recognizer.setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) { recognizer.destroy() }
        override fun onResults(results: Bundle?) {
            val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!heard.isNullOrBlank()) onResult(heard)
            recognizer.destroy()
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    })
    recognizer.startListening(intent)
}

@Composable
private fun SettingsScreen(prefs: BmoPrefs, startOverlay: () -> Unit, modifier: Modifier = Modifier) {
    var base by remember { mutableStateOf(prefs.baseUrl) }
    var key by remember { mutableStateOf(prefs.apiKey) }
    var wake by remember { mutableStateOf(prefs.wakeEnabled) }
    var sensitivity by remember { mutableFloatStateOf(prefs.sensitivity) }
    var speed by remember { mutableFloatStateOf(prefs.speed) }
    var language by remember { mutableStateOf(prefs.language) }
    var saved by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("AI backend", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(base, { base = it }, label = { Text("API base URL / chat completions endpoint") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(key, { key = it }, label = { Text("API key") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
        Text("Language")
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            listOf("English", "Iraqi Arabic", "Auto").forEachIndexed { index, item ->
                SegmentedButton(selected = language == item, onClick = { language = item }, shape = SegmentedButtonDefaults.itemShape(index, 3)) { Text(item, maxLines = 1) }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Wake word: BMO", Modifier.weight(1f)); Switch(checked = wake, onCheckedChange = { wake = it }) }
        Text("Wake-word sensitivity (saved for engine integration): ${(sensitivity * 100).toInt()}%")
        Slider(value = sensitivity, onValueChange = { sensitivity = it }, valueRange = 0.1f..0.9f)
        Text("Voice speed: ${"%.1f".format(speed)}×")
        Slider(value = speed, onValueChange = { speed = it }, valueRange = 0.7f..1.3f)
        Text("Privacy: speech recognition starts only when you tap the microphone. Background wake-word listening is not enabled in this starter build.", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
        Button(onClick = { prefs.baseUrl = base; prefs.apiKey = key; prefs.wakeEnabled = wake; prefs.sensitivity = sensitivity; prefs.speed = speed; prefs.language = language; saved = true }, modifier = Modifier.fillMaxWidth()) { Text("Save settings") }
        if (saved) Text("Settings saved!", color = Teal)
        OutlinedButton(onClick = startOverlay, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PictureInPictureAlt, null); Spacer(Modifier.width(8.dp)); Text("Enable floating BMO overlay") }
    }
}

@Composable
private fun HistoryScreen(messages: List<ChatMessage>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Conversation history", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages.reversed()) { msg ->
                Card { Column(Modifier.padding(12.dp)) { Text(msg.user, color = Teal, fontWeight = FontWeight.SemiBold); Text(msg.assistant) } }
            }
        }
    }
}
