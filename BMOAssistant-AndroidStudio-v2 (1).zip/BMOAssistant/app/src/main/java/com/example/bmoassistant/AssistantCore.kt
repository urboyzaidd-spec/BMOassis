package com.example.bmoassistant

import android.content.Context
import android.content.SharedPreferences
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

enum class BmoState { IDLE, LISTENING, THINKING, SPEAKING }

data class ChatMessage(val user: String, val assistant: String, val time: Long = System.currentTimeMillis())

class BmoPrefs(context: Context) {
    private val p: SharedPreferences = context.getSharedPreferences("bmo_settings", Context.MODE_PRIVATE)
    var baseUrl: String get() = p.getString("base_url", "https://YOUR_BACKEND_URL/v1/chat/completions") ?: ""
        set(v) = p.edit().putString("base_url", v).apply()
    var apiKey: String get() = p.getString("api_key", "YOUR_API_KEY") ?: ""
        set(v) = p.edit().putString("api_key", v).apply()
    var wakeEnabled: Boolean get() = p.getBoolean("wake_enabled", false)
        set(v) = p.edit().putBoolean("wake_enabled", v).apply()
    var sensitivity: Float get() = p.getFloat("sensitivity", 0.55f)
        set(v) = p.edit().putFloat("sensitivity", v).apply()
    var speed: Float get() = p.getFloat("speed", 1f)
        set(v) = p.edit().putFloat("speed", v).apply()
    var language: String get() = p.getString("language", "English") ?: "English"
        set(v) = p.edit().putString("language", v).apply()
    var muted: Boolean get() = p.getBoolean("muted", false)
        set(v) = p.edit().putBoolean("muted", v).apply()
}

class AiClient(private val prefs: BmoPrefs) {
    private val client = OkHttpClient()
    suspend fun reply(prompt: String): String = withContext(Dispatchers.IO) {
        val url = prefs.baseUrl.trim()
        if (url.isBlank() || url.contains("YOUR_BACKEND_URL")) {
            return@withContext "Beep boop! I'm BMO. Add your AI backend URL and API key in Settings, and then I can answer that for real!"
        }
        val body = JSONObject().apply {
            put("model", "gpt-4o-mini")
            put("messages", JSONArray().put(JSONObject().put("role", "system").put("content",
                "You are BMO, a cheerful, playful, helpful handheld game-console assistant. Never claim to be human. Reply in simple friendly English unless the user explicitly asks for Arabic. Understand English and Iraqi Arabic. Keep answers concise and natural."))
                .put(JSONObject().put("role", "user").put("content", prompt)))
            put("temperature", 0.7)
        }.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder().url(url).post(body)
            .header("Authorization", "Bearer ${prefs.apiKey}")
            .header("Content-Type", "application/json").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext "Oh! My connection got a little wobbly (${response.code}). Check the backend settings."
            val json = JSONObject(response.body?.string().orEmpty())
            json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                ?.takeIf { it.isNotBlank() } ?: "Beep boop! I couldn't understand the answer from my server."
        }
    }
}

fun ttsLocale(language: String): Locale = when (language) {
    "Iraqi Arabic" -> Locale("en", "US") // replies remain English by default
    "Auto" -> Locale.getDefault().takeIf { it.language == "ar" } ?: Locale.US
    else -> Locale.US
}
