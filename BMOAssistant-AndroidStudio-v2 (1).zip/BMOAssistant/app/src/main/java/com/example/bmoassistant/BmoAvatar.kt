package com.example.bmoassistant

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.sin

@Composable
fun BmoAvatar(state: BmoState, modifier: Modifier = Modifier, compact: Boolean = false) {
    val infinite = rememberInfiniteTransition(label = "bmo")
    val bounce by infinite.animateFloat(
        initialValue = 0f, targetValue = if (state == BmoState.IDLE) 4f else 1.5f,
        animationSpec = infiniteRepeatable(tween(if (state == BmoState.IDLE) 1400 else 500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bounce"
    )
    val blink by infinite.animateFloat(1f, 0.15f, animationSpec = infiniteRepeatable(tween(120, delayMillis = 2800), RepeatMode.Reverse), label = "blink")
    val mouth by infinite.animateFloat(2f, 9f, animationSpec = infiniteRepeatable(tween(180), RepeatMode.Reverse), label = "mouth")
    Canvas(modifier = modifier) {
        val w = size.width; val h = size.height
        val scale = minOf(w / 240f, h / 300f)
        val ox = (w - 240f * scale) / 2
        val oy = (h - 300f * scale) / 2 + bounce * scale
        fun pt(x: Float, y: Float) = Offset(ox + x * scale, oy + y * scale)
        fun rect(x: Float, y: Float, ww: Float, hh: Float) = androidx.compose.ui.geometry.Rect(ox+x*scale, oy+y*scale, ox+(x+ww)*scale, oy+(y+hh)*scale)
        fun rr(color: Color, x: Float, y: Float, ww: Float, hh: Float, radius: Float) {
            drawRoundRect(color, topLeft = pt(x, y), size = Size(ww*scale, hh*scale), cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius*scale))
        }
        // holographic ground glow
        drawCircle(Color(0x5539F5D0), 106f * scale, pt(120f, 272f))
        // legs and shoes
        drawLine(Color(0xFF087F80), pt(77f, 239f), pt(72f, 268f), 12f*scale, cap=StrokeCap.Round)
        drawLine(Color(0xFF087F80), pt(164f, 239f), pt(169f, 268f), 12f*scale, cap=StrokeCap.Round)
        rr(Color(0xFF075B60), 48f,260f,48f,19f,10f)
        rr(Color(0xFF075B60), 145f,260f,48f,19f,10f)
        // arms
        drawLine(Color(0xFF0C9F9C), pt(35f, 153f), pt(15f, 189f), 13f*scale, cap=StrokeCap.Round)
        drawLine(Color(0xFF0C9F9C), pt(205f, 153f), pt(225f, 185f), 13f*scale, cap=StrokeCap.Round)
        drawCircle(Color(0xFF6DF5D5), 7f*scale, pt(15f,190f))
        drawCircle(Color(0xFF6DF5D5), 7f*scale, pt(225f,186f))
        // console body and glossy highlight
        drawRoundRect(brush=Brush.linearGradient(listOf(Color(0xFF62F0D0), Color(0xFF16B9B5), Color(0xFF087B86)), start=pt(35f,35f), end=pt(190f,250f)), topLeft=pt(34f,25f), size=Size(172f*scale,225f*scale), cornerRadius=androidx.compose.ui.geometry.CornerRadius(24f*scale))
        drawRoundRect(Color(0xFF063D4C), topLeft=pt(49f,42f), size=Size(142f*scale,142f*scale), cornerRadius=androidx.compose.ui.geometry.CornerRadius(12f*scale))
        drawRoundRect(Brush.linearGradient(listOf(Color(0xFF163E4C), Color(0xFF081F32))), topLeft=pt(54f,47f), size=Size(132f*scale,132f*scale), cornerRadius=androidx.compose.ui.geometry.CornerRadius(8f*scale))
        val eyeY = if (state == BmoState.THINKING) 90f else 91f
        val eyeColor = if (state == BmoState.LISTENING) Color(0xFF9BFFE9) else Color(0xFFE2FFF8)
        if (state == BmoState.THINKING) {
            drawArc(eyeColor, 210f, 300f, false, topLeft=pt(90f,70f), size=Size(60f*scale,60f*scale), style=Stroke(4f*scale))
        } else {
            rr(eyeColor, 77f,eyeY,17f, if (state == BmoState.IDLE) 19f*blink else 19f,5f)
            rr(eyeColor, 146f,eyeY,17f, if (state == BmoState.IDLE) 19f*blink else 19f,5f)
        }
        if (state == BmoState.SPEAKING) {
            drawOval(Color(0xFFFF9D9B), topLeft = pt(105f,132f), size = Size(30f*scale,mouth*scale))
        } else if (state == BmoState.THINKING) {
            drawLine(Color(0xFFB7FFF0), pt(104f,143f), pt(136f,143f), 3f*scale, cap=StrokeCap.Round)
        } else {
            drawLine(Color(0xFFFFB5A8), pt(103f,137f), pt(137f,137f), 3f*scale, cap=StrokeCap.Round)
        }
        // controls, speaker slots and details
        drawCircle(Color(0xFFFFD36E), 7f*scale, pt(76f,207f))
        drawCircle(Color(0xFFEF7AB8), 7f*scale, pt(163f,207f))
        drawLine(Color(0xFF075D68), pt(100f,205f), pt(140f,205f), 3f*scale, cap=StrokeCap.Round)
        drawLine(Color(0xFF075D68), pt(100f,213f), pt(140f,213f), 3f*scale, cap=StrokeCap.Round)
        // little status glint
        drawCircle(Color(0xFFD9FFF7), 2.4f*scale, pt(185f,40f))
    }
}
